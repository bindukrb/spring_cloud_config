package com.mphasis.bookStore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.mphasis.bookStore.entity.Book;
import com.mphasis.bookStore.repository.BookRepository;

@SpringBootApplication
public class BookAppStoreApplication implements CommandLineRunner{
	
	@Autowired 
	@Qualifier("bookrepo") 
	private BookRepository bookrepo;

	public static void main(String[] args) {
		SpringApplication.run(BookAppStoreApplication.class, args);
		
		System.out.println("running perfectly..!");
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("working");
		
		bookrepo.save(new Book(0,".Net","publisher1",250,2018)); 

		bookrepo.save(new Book(0,"Java","publisher2",350,2020)); 

		bookrepo.save(new Book(0,"Angular","publisher3",150,2013)); 

		bookrepo.save(new Book(0,"Spring","publisher4",250,2019)); 

		System.out.println(bookrepo.findAll()); 
		
	}
	

}
