package com.mphasis.bookStore.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.mphasis.bookStore.entity.Book;
import com.mphasis.bookStore.repository.BookRepository;

@Service("bookserv")
@Scope("singleton")
public  class bookService implements bookIService{

	@Autowired 
	@Qualifier("bookrepo") 
	private BookRepository bookrepo;

	@Override
	public List<Book> getAllBooks() {
		
		return bookrepo.findAll();
	}
	
	@Override
	public Book save(Book bookDetails) {
		
		return bookrepo.save(bookDetails);
	}

	@Override
	public Book update(Book bookDetails) {
		
		return bookrepo.save(bookDetails);
	}

	@Override
	public void delete(int id) {
		bookrepo.deleteById(id);
		
	}

	@Override
	public Book getBookById(int id) {
		
		return bookrepo.findById(id).get();
	}

	@Override
	public List<Book> getAllBooksByYear(int year) {
		return bookrepo.findByYear(year);
	}

	@Override
	public List<Book> getAllBooksByTitle(String title) {
		
		return bookrepo.findByTitleLike(title);
	}

	@Override
	public void patchBook(Map<String, Object> updates, int id) {
		
		Book dbBook= bookrepo.findById(id).get();
		Integer year= (Integer)updates.get("year");
		if(year !=null) {
			
			dbBook.setYear(year);
			bookrepo.save(dbBook);
		}
	}

	@Override
	public List<Book> getAllBooksByPublisher(String publisher) {
		
		return bookrepo.findByPublisherLike(publisher);
	}
	
	
	
}
