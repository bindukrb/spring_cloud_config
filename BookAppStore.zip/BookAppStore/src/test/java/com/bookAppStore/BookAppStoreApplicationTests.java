package com.bookAppStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookAppStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
